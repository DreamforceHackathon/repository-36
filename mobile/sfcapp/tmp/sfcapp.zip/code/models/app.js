//

var _3Model = require("3vot-model")

App = _3Model.setup("Company", ["name","logo","url"]);

module.exports= App